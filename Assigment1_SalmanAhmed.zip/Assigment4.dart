void main(){
  int year=2020;
  if(year%4==0){
    print("This Is Leap Year");
  }
  else{
    print("This Is Not A Leap Year");
  }


}