void main() {
  int length = 5;
  int breadth = 5;

  if (length == breadth) {
    print("It's a square.");
  } else {
    print("It's a rectangle.");
  }
}