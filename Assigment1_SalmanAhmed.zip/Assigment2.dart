void main(){
    int age1 = 20;
    int age2 = 40;

    if (age1 > age2){
        print("Age1 Is Oldest");
        print("Age2 Is Youngest");
    }

    else if (age1 < age2){
       print("Age1 Is Youngest");
        print("Age2 Is Oldest"); 
    }

    else{
        print("Both Are Equal");
    }
}