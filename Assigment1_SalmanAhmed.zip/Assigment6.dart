void main(){
  var char='i';
  if(char=='a' || char=='e' || char=='i' || char=='o' || char=='u'){
    print('This Is Vowel Word');
  }
  else{
    print('this is Constant Word');
  }
}