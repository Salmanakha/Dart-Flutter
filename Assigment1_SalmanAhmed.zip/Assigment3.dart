void main() {
  int class_held=16;
  int class_attend=10;
  double percentage = (class_attend/class_held*100) as double;

  if(percentage>=75)
  {
    print("You Can Sit In Exam Hall");
  }
  else{
        print("You Can Sit In Exam Hall");

  }

}